# AdCP Request Signing Conformance Vectors

Test vectors for the AdCP RFC 9421 request-signing profile. These fixtures drive cross-implementation conformance testing so a signer written in one SDK and a verifier written in another agree on the wire format.

Specification: [Signed Requests (Transport Layer)](https://adcontextprotocol.org/docs/building/by-layer/L1/security#signed-requests-transport-layer) in `docs/building/by-layer/L1/security.mdx`.

**Canonical URLs.** These vectors are served at `https://adcontextprotocol.org/compliance/{version}/test-vectors/request-signing/`, with `{version}` being either a specific immutable release (e.g. `3.0.0`) or `latest` (the moving development snapshot, which can be ahead of GA). Tree preserved — `keys.json`, `canonicalization.json`, `body-integrity-policy.json`, `protocol-method-names.json`, `negative/*.json`, `profile-3.2/{positive,negative}/*.json`, and `positive/*.json` are all resolvable. SDKs SHOULD pin a released version path and record it rather than requiring a checkout of the spec repo; use `latest` only for development testing. Example: `https://adcontextprotocol.org/compliance/3.0.26/test-vectors/request-signing/protocol-method-names.json`.

## Scope

These vectors exercise the [verifier checklist](https://adcontextprotocol.org/docs/building/by-layer/L1/security#verifier-checklist-requests) and the RFC 9421 profile constraints: covered components, signature parameters, tag namespace, alg allowlist, `adcp_use` key-purpose discriminator, replay dedup, revocation, and content-digest semantics. They do not exercise live JWKS fetch, brand.json discovery, or revocation-list polling — those require live endpoints and belong in integration suites.

## File layout

```
test-vectors/request-signing/
├── README.md                             this file
├── keys.json                             test keypairs (Ed25519 + ES256) in JWK format with adcp_use values
├── canonicalization.json                 pure URL-canonicalization cases (no crypto) — every rule from the @target-uri algorithm + malformed-authority rejections
├── body-integrity-policy.json            3.2 substitution, list-mode, fallback-auth, downgrade, and no-body policy matrix
├── protocol-method-names.json            3.2 A2A 0.3/1.0 declaration grammar and exact decoded-string matching cases
├── negative/                             legacy 3.1 vectors that MUST fail verification
│   ├── 001-no-signature-header.json      → request_signature_required (pre-check 0; op in required_for)
│   ├── 002-wrong-tag.json                → request_signature_tag_invalid (step 3)
│   ├── 003-expired-signature.json        → request_signature_window_invalid (step 5; expired)
│   ├── 004-window-too-long.json          → request_signature_window_invalid (step 5; window > 300s)
│   ├── 005-alg-not-allowed.json          → request_signature_alg_not_allowed (step 4)
│   ├── 006-missing-covered-component.json → request_signature_components_incomplete (step 6; @authority missing)
│   ├── 007-missing-content-digest.json   → request_signature_components_incomplete (step 6; policy 'required')
│   ├── 008-unknown-keyid.json            → request_signature_key_unknown (step 7)
│   ├── 009-key-ops-missing-verify.json   → request_signature_key_purpose_invalid (step 8; adcp_use mismatch)
│   ├── 010-content-digest-mismatch.json  → request_signature_digest_mismatch (step 11)
│   ├── 011-malformed-header.json         → request_signature_header_malformed (step 1; downgrade protection)
│   ├── 012-missing-expires-param.json    → request_signature_params_incomplete (step 2)
│   ├── 013-expires-le-created.json       → request_signature_window_invalid (step 5; expires ≤ created)
│   ├── 014-missing-nonce-param.json      → request_signature_params_incomplete (step 2)
│   ├── 015-signature-invalid.json        → request_signature_invalid (step 10; canonicalization catcher)
│   ├── 016-replayed-nonce.json           → request_signature_replayed (step 12; requires test_harness_state preload)
│   ├── 017-key-revoked.json              → request_signature_key_revoked (step 9; requires test_harness_state preload)
│   ├── 018-digest-covered-when-forbidden.json → request_signature_components_unexpected (step 6; policy 'forbidden')
│   ├── 019-signature-without-signature-input.json → request_signature_header_malformed (pre-check; downgrade loophole)
│   ├── 020-rate-abuse.json               → request_signature_rate_abuse (step 9a cap; abuse signal)
│   ├── 021-duplicate-signature-input-label.json → request_signature_header_malformed (step 1; RFC 8941 dict duplicate-key)
│   ├── 022-multi-valued-content-type.json → request_signature_header_malformed (step 1; covered non-list field must be single-valued)
│   ├── 023-multi-valued-content-digest.json → request_signature_header_malformed (step 1; RFC 9530 dict duplicate algorithm)
│   ├── 024-unquoted-string-param.json     → request_signature_header_malformed (step 1; RFC 8941 §3.3 string values must be quoted)
│   ├── 025-jwk-alg-crv-mismatch.json      → request_signature_key_purpose_invalid (step 8; alg=EdDSA with crv=P-256 is impossible per RFC 8037)
│   ├── 026-non-ascii-host.json            → request_target_uri_malformed (step 10; raw IDN U-label on wire; MUST be A-label; real signature over the A-label base)
│   ├── 027-webhook-registration-authentication-unsigned.json → request_signature_required (webhook-reg with push_notification_config.authentication over bearer on a seller supporting signing; operation NOT in required_for; transitional deprecated condition (b), graded only when `webhook_signing.legacy_hmac_fallback` is `true`, skipped otherwise)
│   ├── 028-unsigned-protocol-method-required.json → request_signature_required (unsigned `tasks/cancel` JSON-RPC POST; method is in `protocol_methods_required_for`)
│   ├── 029-duplicate-signature-label.json → request_signature_header_malformed (step 1; RFC 9421 §4.2 / RFC 8941 §3.2 duplicate key on the `Signature` header)
│   ├── 030-content-digest-key-case.json   → request_signature_header_malformed (step 1; RFC 8941 §3.1.2 keys are lowercase only — `SHA-256` is not a synonym of `sha-256`)
│   └── 031-malformed-host-authority.json  → request_target_uri_malformed (step 10; unbracketed IPv6 literal in the `Host` header, URL clean, real signature)
├── a2a/                                  A2A operation-resolution vectors (adcp#7820, 33 vectors): `required_for` over A2A; see "A2A operation-resolution vectors" below
├── profile-3.2/                          3.2 vectors: RFC 8941 Base64 sf-binary, content-digest covered, covers_content_digest 'required'
│   ├── positive/                         counterparts keep the root vector's number and slug; the absence of `positive/001-basic-post` and `positive/002-post-with-content-digest` is by design (both map to `001-post-with-content-digest`)
│   │   ├── 001-post-with-content-digest.json                  RFC 8941 Base64 + required body binding (3.2 counterpart of root 001 and 002)
│   │   ├── 003-es256-post.json                                 ES256
│   │   ├── 004-multiple-signature-labels.json                  verifier processes sig1 only
│   │   ├── 005-default-port-stripped.json
│   │   ├── 006-dot-segment-path.json
│   │   ├── 007-query-byte-preserved.json
│   │   ├── 008-percent-encoded-path.json
│   │   ├── 009-percent-encoded-unreserved-decoded.json
│   │   ├── 010-percent-encoded-slash-preserved.json
│   │   ├── 011-ipv6-authority.json
│   │   ├── 012-ipv6-authority-default-port-stripped.json
│   │   ├── 013-two-signature-labels-distinct.json              guard for negative/029
│   │   ├── 014-content-digest-two-algorithms.json              guard for negative/030
│   │   └── 015-bracketed-ipv6-host-with-port.json              guard for negative/031
│   └── negative/
│       ├── 001-base64url-sf-binary.json       → request_signature_header_malformed (3.2-only; legacy alphabet)
│       ├── 001-no-signature-header.json       → request_signature_required (pre-check; unsigned, Content-Digest sent)
│       ├── 002-multiple-trailing-dots.json    → request_target_uri_malformed (3.2-only; empty DNS label)
│       ├── 002-wrong-tag.json                 → request_signature_tag_invalid (step 3)
│       ├── 003-expired-signature.json         → request_signature_window_invalid (step 5)
│       ├── 004-window-too-long.json           → request_signature_window_invalid (step 5)
│       ├── 005-alg-not-allowed.json           → request_signature_alg_not_allowed (step 4)
│       ├── 006-missing-covered-component.json → request_signature_components_incomplete (step 6)
│       ├── 007-missing-content-digest.json    → request_signature_components_incomplete (step 6; unconditional in 3.2)
│       ├── 008-unknown-keyid.json             → request_signature_key_unknown (step 7)
│       ├── 009-key-ops-missing-verify.json    → request_signature_key_purpose_invalid (step 8)
│       ├── 010-content-digest-mismatch.json   → request_signature_digest_mismatch (step 11)
│       ├── 011-malformed-header.json          → request_signature_header_malformed (step 1; unparseable Signature-Input, placeholder Signature)
│       ├── 012-missing-expires-param.json     → request_signature_params_incomplete (step 2)
│       ├── 013-expires-le-created.json        → request_signature_window_invalid (step 5)
│       ├── 014-missing-nonce-param.json       → request_signature_params_incomplete (step 2)
│       ├── 015-signature-invalid.json         → request_signature_invalid (step 10)
│       ├── 016-replayed-nonce.json            → request_signature_replayed (step 12; requires test_harness_state preload)
│       ├── 017-key-revoked.json               → request_signature_key_revoked (step 9; requires test_harness_state preload)
│       ├── 019-signature-without-signature-input.json → request_signature_header_malformed (pre-check; real Signature, Signature-Input stripped, operation outside required_for)
│       ├── 020-rate-abuse.json                → request_signature_rate_abuse (step 9a; requires test_harness_state preload)
│       ├── 021-duplicate-signature-input-label.json → request_signature_header_malformed (step 1; real Signature)
│       ├── 022-multi-valued-content-type.json → request_signature_header_malformed (step 1; real Signature)
│       ├── 023-multi-valued-content-digest.json → request_signature_header_malformed (step 1; real Signature)
│       ├── 024-unquoted-string-param.json     → request_signature_header_malformed (step 1; real Signature)
│       ├── 025-jwk-alg-crv-mismatch.json      → request_signature_key_purpose_invalid (step 8; jwks_override)
│       ├── 026-non-ascii-host.json            → request_target_uri_malformed (step 10; raw U-label on the wire, real Signature over the A-label base)
│       ├── 027-webhook-registration-authentication-unsigned.json → request_signature_required (pre-check; unsigned)
│       ├── 028-unsigned-protocol-method-required.json → request_signature_required (pre-check; unsigned)
│       ├── 029-duplicate-signature-label.json → request_signature_header_malformed (step 1; real Signature repeated under `sig1`)
│       ├── 030-content-digest-key-case.json   → request_signature_header_malformed (step 1; `SHA-256` and `sha-256`, real Signature)
│       └── 031-malformed-host-authority.json  → request_target_uri_malformed (step 10; unbracketed IPv6 `Host`, URL clean, real Signature)
└── positive/                             vectors that MUST verify successfully
    ├── 001-basic-post.json                   Ed25519, no content-digest
    ├── 002-post-with-content-digest.json     Ed25519, content-digest covered
    ├── 003-es256-post.json                   ES256, no content-digest
    ├── 004-multiple-signature-labels.json    Two Signature-Input labels; verifier processes sig1 only
    ├── 005-default-port-stripped.json        URL has :443; canonical strips it
    ├── 006-dot-segment-path.json             Path has /./; canonical collapses it
    ├── 007-query-byte-preserved.json         Query b=2&a=1&c=3 — preserved, not alphabetized
    ├── 008-percent-encoded-path.json         Path has lowercase %xx; canonical uppercases
    ├── 009-percent-encoded-unreserved-decoded.json  Path has %7E/%2D/%5F/%2E; canonical decodes unreserved per RFC 3986 §6.2.2.2
    ├── 010-percent-encoded-slash-preserved.json     Path has %2F (reserved); stays percent-encoded, not treated as segment separator
    ├── 011-ipv6-authority.json                       IPv6 literal host; brackets preserved in @target-uri and @authority
    ├── 012-ipv6-authority-default-port-stripped.json IPv6 literal with :443; port stripped, brackets preserved
    ├── 013-two-signature-labels-distinct.json        sig1 and sig2 on both Signature-Input and Signature; guard for negative/029
    ├── 014-content-digest-two-algorithms.json       Content-Digest with sha-256 and sha-512, both correct; guard for negative/030
    └── 015-bracketed-ipv6-host-with-port.json        Host: [2001:db8::1]:8443 matches the URL authority; guard for negative/031
```

## Canonicalization vectors (`canonicalization.json`)

`canonicalization.json` is a flat set of URL-canonicalization cases that exercise every rule in the `@target-uri` canonicalization algorithm, plus the malformed-authority rejection cases. Independent of cryptographic signing — an SDK can run this file without keys, crypto, or a full verifier harness, which makes it the fastest way to surface cross-implementation divergence.

Shape:

```json
{
  "spec_reference": "#adcp-rfc-9421-profile",
  "cases": [
    {
      "name": "ipv6-host-hex-lowercased",
      "rule": "step 2: IPv6 brackets preserved; hex digits inside lowercased",
      "input_url": "https://[2001:DB8::1]/p",
      "expected_target_uri": "https://[2001:db8::1]/p",
      "expected_authority": "[2001:db8::1]"
    },
    {
      "name": "malformed-port-without-host",
      "rule": "step 3: authority with port but no host is malformed",
      "input_url": "https://:443/p",
      "reject": true,
      "reject_reason": "authority missing host",
      "expected_error_code": "request_signature_header_malformed"
    }
  ]
}
```

For each case:

- **Positive case** (no `reject` field): the implementation MUST canonicalize `input_url` and produce byte-for-byte matches on `expected_target_uri` and `expected_authority`. Each case also carries a `rule` string pointing to the specific numbered step in the canonicalization algorithm it exercises — useful when a test fails and you want to know which rule the implementation got wrong.
- **Reject case** (`reject: true`): the implementation MUST refuse to canonicalize `input_url`. Signers refuse to sign; verifiers reject with `expected_error_code`.

SDKs SHOULD run `canonicalization.json` on every commit alongside a lint pass. Canonicalization divergence is the #1 silent 9421 interop bug, and catching it as a fast unit test (cheap, no network, no crypto) closes that gap.

## Vector format

Every vector is a single JSON file with this shape:

```json
{
  "name": "human-readable description",
  "spec_reference": "#anchor in security.mdx (checklist step or pre-check)",
  "signing_profile_version": "3.2",
  "reference_now": 1776520800,
  "request": {
    "method": "POST",
    "url": "https://seller.example.com/adcp/create_media_buy",
    "headers": {
      "Content-Type": "application/json",
      "Signature-Input": "sig1=(...)",
      "Signature": "sig1=:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==:",
      "Content-Digest": "sha-256=:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=:"
    },
    "body": "{\"...\":\"...\"}"
  },
  "verifier_capability": {
    "supported": true,
    "covers_content_digest": "required",
    "required_for": ["create_media_buy"]
  },
  "jwks_ref": ["test-ed25519-2026"],
  "jwks_override": { "keys": [ "..." ] },
  "test_harness_state": {
    "replay_cache_entries": [ "..." ],
    "revocation_list": { "..." }
  },
  "expected_signature_base": "\"@method\": POST\n...",
  "expected_outcome": {
    "success": false,
    "error_code": "request_signature_window_invalid",
    "failed_step": 5
  },
  "$comment": "optional free-form notes"
}
```

### Fields

- **`name`** — one-line description.
- **`spec_reference`** — anchor in `security.mdx` the vector tests, including the checklist step number.
- **`signing_profile_version`** — version whose signing semantics the vector exercises. Every fixture in the root `positive/` and `negative/` directories is pinned to `3.1`; 3.2 verifiers MUST NOT silently reinterpret them as 3.2 cases.
- **`reference_now`** — Unix seconds. Treat as the wall-clock value the verifier should use when evaluating the signature window. Inject into your test harness rather than using `Date.now()`.
- **`request`** — the raw HTTP request the verifier receives. `headers` is case-insensitive; `body` is the exact byte string on the wire (empty string for GETs).
- **Binary header values** — the 3.1 fixtures preserve AdCP's legacy unpadded Base64URL override. Profile 3.2 uses RFC 8941 `sf-binary`: standard Base64 with required padding, not Base64URL. The zero-byte values above illustrate the 3.2 wire grammar only; real vectors contain cryptographically valid bytes.
- **`verifier_capability`** — the `request_signing` block the verifier advertises. Drives expected behavior on content-digest coverage (`"required"` | `"forbidden"` | `"either"`) and whether unsigned requests to the operation are rejected pre-check.
- **`jwks_ref`** — array of `kid` strings from `keys.json`. The test harness builds the verifier's view of the signing agent's JWKS by selecting those entries. Present on most vectors.
- **`jwks_override`** — full JWKS object (`{ keys: [...] }`) that replaces the default `jwks_ref` lookup for this vector. Used when a vector needs a JWK that is NOT in the canonical `keys.json` (e.g., a malformed `key_ops` to test step 8 rejection). Mutually exclusive with `jwks_ref`.
- **`test_harness_state`** — optional. Preloads verifier state BEFORE invoking verification. Harness implementations translate each sub-key into the appropriate concrete preload for their verifier under test. Supported sub-keys:
  - `replay_cache_entries` — list of `{ keyid, nonce, ttl_seconds }` to preload into the per-`(keyid, nonce)` replay cache. Used by `016-replayed-nonce.json` to assert the nonce-dedup check at step 12.
  - `replay_cache_per_keyid_cap_hit` — object `{ keyid }` signalling the per-keyid entry cap is hit for the named key. Used by `020-rate-abuse.json` to assert the cap check at step 9a. The harness MAY simulate by populating the cache with N placeholder entries (where N equals the verifier's configured cap) or by setting an implementation-private flag — what the vector asserts is the rejection behavior when the cap is hit, not the mechanism of reaching it.
  - `revocation_list` — full signed-revocation-list object to preload as the current freshness snapshot. Used by `017-key-revoked.json` to assert the revocation check at step 9.
- **`expected_signature_base`** — present on positive vectors and on `015-signature-invalid.json`. The canonical signature base string per RFC 9421 §2.5. Shape specifics that implementers get wrong: **lines are joined with a single `\n`** (LF, not CRLF); **there is no trailing newline** after the final `@signature-params` line; **components appear in the exact order listed in `Signature-Input`**, followed by `@signature-params` as the last line. The JSON string uses `\n` escapes which parse to real newline bytes at load time. Implementers can diff their computed base against this field BEFORE worrying about signatures — canonicalization disagreements are the #1 source of 9421 interop bugs, and checking the base is how you catch them.
- **`expected_outcome.success`** — `true` for positive vectors, `false` for negative.
- **`expected_outcome.error_code`** — stable code from the [transport error taxonomy](https://adcontextprotocol.org/docs/building/by-layer/L1/security#transport-error-taxonomy). Conformance requires **byte-for-byte match** on this code. Negative vectors only.
- **`expected_outcome.failed_step`** — which step of the verifier checklist the rejection occurs at. Integer for numbered steps (`1`–`13`), or a string for lettered sub-steps (e.g. `"9a"` for the per-keyid cap check). Informational only — an implementation that rejects with the correct error code is conformant even if its internal step numbering differs. An implementation that rejects with a DIFFERENT error code is non-conformant (see [Conformance expectations](#conformance-expectations)). Negative vectors only.
- **`$comment`** — free-form clarifying notes. Some vectors use `$comment` to describe test-harness setup or conformance edge cases.

## A2A operation-resolution vectors

`a2a/{positive,negative}/` grade [Operation resolution over A2A](https://adcontextprotocol.org/docs/building/by-layer/L1/security#operation-resolution-over-a2a): `required_for` / `supported_for` / `warn_for` match the AdCP operation a verifier resolves from the request, which for A2A is the `skill` of the Message's sole DataPart and not the JSON-RPC `method` (`SendMessage`, `SendStreamingMessage`, `message/send`, `message/stream`). A 3.2 verifier MUST pass every `contradiction-resolution` vector, which grades the security erratum that resolves the contradiction between `security.mdx` and the A2A profile. `hardening` vectors grade clauses that go further and are SHOULD in 3.2.x and MUST from 3.3. The corpus is generated by [`scripts/generate-request-signing-a2a-vectors.mjs`](https://github.com/adcontextprotocol/adcp/blob/main/scripts/generate-request-signing-a2a-vectors.mjs) (`--check` verifies the committed files are current) and uses the 3.2 wire profile unchanged: `content-digest` covered, RFC 8941 `sf-binary`, Ed25519 test key.

Differences from the root vector format:

- **`request.url`** is the A2A JSON-RPC endpoint and **`request.body`** is the JSON-RPC request. The verifier derives the operation from the body, not from the URL.
- **No unsigned vector carries an `Authorization` header**, so no fallback credential applies and an unsigned request to an operation in `required_for` rejects with `request_signature_required`.
- **`expected_outcome.status`** is `verified` (valid signature) or `unsigned` (no signature required for the resolved operation, so the request proceeds to dispatch).
- **`expected_outcome.resolved_operation`** is the operation the verifier MUST resolve. Where the vector says `dispatched_operation` or `dispatch`, the agent MUST also dispatch exactly that operation (or reject an unknown skill as unsupported) and MUST NOT re-derive it from TextParts, metadata, or a case-insensitive alias.
- **`request_body_malformed` at `failed_step: 0`** means the body does not resolve to exactly one operation. It applies whether or not the request is signed, and a valid signature does not change the outcome. Resolution runs before the signature-header checks, so `negative/018` expects `request_body_malformed` even though a header pair is also malformed.
- **`tier`** is `contradiction-resolution` or `hardening`; see above.
- **`verifier_capability.operation_sources`** is present on every vector, because each one grades a verifier that claims `a2a_invocation_skill`, which commits it to both tiers. A harness MAY strip it before handing the capability to a verifier that predates the field.
- **`failed_step: 0`** is the pre-check, not a numbered checklist step. (The general `failed_step` field above otherwise names steps 1 to 13.)
- **Bindings.** `negative/022` uses the A2A HTTP+JSON binding (`POST …/message:send`), which has no JSON-RPC `method`; the other vectors use the JSON-RPC binding.
- **Deriving the operation.** For these vectors the harness resolves the operation from the body per the resolution rule, not from the URL (step 5 of "Running vectors against an implementation" describes the root vectors).

`warn_for` and `supported_for` use the same resolved operation and lookup as `required_for` and have no separate vectors. Not covered by static vectors, and therefore by the checklist text alone: the `message.taskId` continuation binding and the gate-to-dispatcher hand-off, which need a stateful agent harness. Vector `023` covers JSON-RPC batch bodies, which are rejected with `request_body_malformed` ([#7565](https://github.com/adcontextprotocol/adcp/issues/7565)).

## Test keypairs

`keys.json` ships three keypairs used across the vectors:

| kid | alg | adcp_use | purpose |
|---|---|---|---|
| `test-ed25519-2026` | EdDSA (Ed25519) | `request-signing` | primary signing key for Ed25519 positive vectors |
| `test-es256-2026` | ES256 | `request-signing` | edge-runtime variant; covers ES256 |
| `test-gov-2026` | EdDSA (Ed25519) | `governance-signing` | included to test the cross-purpose rejection rule at checklist step 8 (vector `009-key-ops-missing-verify` presents this key when verifying a request signature) |

The private-key halves are present in `keys.json` as `_private_d_for_test_only` so implementations can regenerate positive-vector signatures deterministically. **These keypairs are for conformance testing only. They are public knowledge and MUST NOT be used in any production capacity.**

## Conformance expectations

An implementation is conformant when, for every vector:

1. **Negative vectors** produce `expected_outcome.error_code` exactly. The `failed_step` is informational: an implementation that rejects with the correct error code is conformant, even if its internal step numbering differs. An implementation that rejects with a DIFFERENT error code (even at the right step) is non-conformant.
2. **Positive vectors** verify without error.
3. **Signature bytes on positive vectors** match `request.headers.Signature` byte-for-byte when the implementation signs with the corresponding key from `keys.json`. Ed25519 is deterministic (001 and 002 will reproduce byte-exact). ES256 uses IEEE P1363 (r||s) encoding per RFC 9421 §3.3.2; ECDSA is non-deterministic by default, so implementations that use random-k are conformant on VERIFY but may not reproduce the `Signature` byte-for-byte. Verifiers are the protocol surface — reproduction of signer bytes is a convenience check, not a normative requirement.

## Generating positive-vector signatures

Positive-vector signatures are computed from the canonical signature base per RFC 9421 §2.5. The base string for each positive vector is in `expected_signature_base` so implementers can check their canonicalization independently of cryptographic signing.

The shipped signatures were generated from those base strings using the corresponding private keys. The legacy 3.1 fixtures and the hand-authored `profile-3.2/positive/001` and `profile-3.2/negative/001`–`002` came from an uncommitted regenerator. The rest of `profile-3.2/` is produced by the committed [`scripts/generate-request-signing-profile-3.2-vectors.mjs`](https://github.com/adcontextprotocol/adcp/blob/main/scripts/generate-request-signing-profile-3.2-vectors.mjs) (`--check` verifies the committed files are current; CI runs it). Do not hand-edit signature bytes.

**Cross-implementation commitment check.** Before relying on the shipped signatures, SDK implementers SHOULD independently compute the signature base from the vector inputs (method, URL, headers, body, covered-components list, sig-params) and compare byte-for-byte against `expected_signature_base` in each positive vector. If all three reference SDKs (TypeScript, Go, Python — see adcp#2323 for tracking issues) agree with the committed base, confidence that the committed `Signature` values are canonical is high. If any disagrees, escalate to the spec repo BEFORE the SDK consumes the signatures — locking a canonicalization bug into the committed signatures would be the worst outcome, because every subsequent verifier would inherit it. The `expected_signature_base` field exists specifically to make this check byte-level and implementation-independent.

## Profile 3.2 vectors

A 3.2 signing peer MUST advertise `covers_content_digest: "required"`, and every accepted signature on a body-bearing request covers `content-digest`. Most root vectors sign without `content-digest`, so a `required` verifier cannot grade them. `profile-3.2/` restores that coverage: each root positive vector and each root negative has a 3.2 counterpart **with the same number and slug** (for example, `profile-3.2/negative/003-expired-signature.json` is the 3.2 version of `negative/003-expired-signature.json`), except the vectors for postures 3.2 forbids. Root vectors that are not mirrored leave gaps in the numbering. Root `positive/001` (basic POST) and `positive/002` (POST with content-digest) are the same request in 3.2, so both map to `profile-3.2/positive/001-post-with-content-digest.json`. `profile-3.2/negative/001` and `002-multiple-trailing-dots` are 3.2-only wire-format vectors that predate this scheme; `002-multiple-trailing-dots` shares its number with the `002-wrong-tag` counterpart, and file names stay unique.

Each counterpart keeps its original's request shape but:

- covers `content-digest` wherever a parseable `Signature-Input` exists. The exceptions are `profile-3.2/negative/007-missing-content-digest`, whose whole point is that it is missing (it still sends a correct `Content-Digest` header, so verifiers must check the covered-components list rather than header presence), and `011`, whose `Signature-Input` is unparseable;
- encodes `Signature` and `Content-Digest` as RFC 8941 `sf-binary` (standard Base64, padded);
- advertises `covers_content_digest: "required"`;
- re-keys the body's `idempotency_key`, so the counterpart is a distinct request.

As in the root corpus, pre-crypto negatives (steps 2–9a) carry a 64-zero-byte placeholder `Signature`. That makes them step-ordering canaries: a verifier that verifies the signature before the targeted check returns `request_signature_invalid`. The post-crypto negatives (`profile-3.2/negative/010` and `016`) carry real signatures, so only the targeted check fails.

The step-0 and step-1 vectors are mirrored with `content-digest` covered, so that the step-0/1 fault is the vector's only fault. Without that, a `required` verifier would also find a step-6 fault (a body-bound signature that does not cover `content-digest`) in `021`, `022`, `024`, `026`, `029` and `031`, and the vector would grade the verifier's evaluation order rather than the step-1 rule. The unsigned vectors (`001`, `027`, `028`) stay unsigned and carry only a correct `Content-Digest`. Where the fault does not depend on the signature bytes (`021`–`024`, `026`, `029`–`031`), the `Signature` is real rather than a placeholder, so a signature the verifier can validate is not a second fault; `021`, `023`, `029` and `030` repeat the same member or value so that keeping either one finds no second fault. `029` and `030` carry real signatures where the root vectors use placeholders, and the root's false-positive guards `positive/013`–`015` are mirrored as well. `031` is a real signature over the base for the clean URL authority, so the malformed `Host` header is the only fault; its `Host` header is carried over unchanged. `019` is a real signature whose `Signature-Input` was stripped, on an operation outside `required_for` so that only the header-pair rule applies; `026` signs the base for the A-label form of the host, so only the raw U-label on the wire is wrong. `011` keeps the placeholder because its `Signature-Input` is unparseable and no signature base exists.

The pre-crypto negatives for steps 2–9a keep their placeholder `Signature`, which predates the single-fault rule below. Whether the step order those canaries grade is normative is the open question in adcp#7577, so they are not rewritten here.

The only root negative without a 3.2 counterpart is one for a posture 3.2 forbids: `018`, because `forbidden` is a legacy-only posture a 3.2 verifier cannot advertise.

## Running vectors against an implementation

A reference harness is in progress at https://github.com/adcontextprotocol/adcp-client/issues/575. Until it lands, implementers consuming these vectors should:

1. Parse each vector JSON.
2. Build a `Request` object from `vector.request.method`, `vector.request.url`, `vector.request.headers`, `vector.request.body`.
3. Build the verifier's JWKS from `vector.jwks_ref` (selecting entries from `keys.json`) or `vector.jwks_override` (use as-is).
4. Preload any `test_harness_state` sub-keys into the verifier's replay cache and revocation snapshot. **Reset verifier state (replay cache, per-keyid cap, revocation snapshot) before every vector.** Vectors are independent: many share a `(keyid, nonce)` pair and a `reference_now`, so a replay cache carried over from an earlier vector rejects a later positive vector as `request_signature_replayed`, and cap or revocation state carried over fails unrelated vectors.
5. Invoke verification with `reference_now` as the wall clock, `vector.verifier_capability` as the advertised capability, and the operation name derived from the request URL or `expected_outcome.failed_step == 0`'s pre-check expectation.
6. Assert:
   - Negative: error code matches `expected_outcome.error_code` exactly.
   - Positive: verification returns successfully.

### Recommended run order

Run vectors in this order when validating a new implementation — it isolates failure categories so a bug surfaces cleanly instead of as a pile of unrelated red tests. The numbers below refer to the root 3.1 corpus; a 3.2 verifier applies the same order to the `profile-3.2/` counterparts (see the mapping in [File layout](#file-layout)):

1. **Positive vectors first** (`positive/001`, `/002`, `/003`, then the false-positive guards `positive/013`, `/014`, `/015` before the negatives they pair with: `negative/029`, `/030`, `/031`). These exercise the happy path. If `001` fails, your signer or verifier's canonicalization, key loading, or crypto is wrong — fix before touching anything else. The `expected_signature_base` field in each positive vector lets you diff YOUR canonical base against the spec's, independent of whether your crypto works.
2. **Parse-level negatives next** (`001`, `002`, `011`, `012`, `014`, `019`, `021`, `023`, `029`, `030`). These fail at the pre-check or early checklist steps without invoking crypto. Passing these means your header parsing and presence checks are correct.
3. **Semantic negatives** (`003`, `004`, `005`, `006`, `007`, `013`, `018`). These exercise specific rules (window, alg allowlist, covered components, content-digest policy) without requiring valid signatures.
4. **Key-path negatives** (`008`, `009`). JWKS resolution + `adcp_use` enforcement.
5. **Stateful pre-crypto negatives** (`017`, `020`). These require preloaded harness state and reject before crypto verify — `017` on revocation (step 9), `020` on the per-keyid cap (step 9a). The committed `Signature` on these vectors is a placeholder and is NOT expected to verify cryptographically; the rejection MUST land on the pre-crypto cheap check.
6. **Crypto / stateful-post negatives last** (`015`, `010`, `016`, `031`). These require the verifier to have run most of the checklist before reaching the failure point. `031` is a real-signature negative: the signature verifies over the URL authority, so only a verifier that also judges the `Host` header rejects it with `request_target_uri_malformed`. `015` specifically catches canonicalization bugs where your implementation computes a different signature base than the spec — if you pass `positive/001` but fail `015`, your canonicalization is still off somewhere and `015` is picking it up.

## Adding vectors

Every new vector MUST:

1. Cite a specific normative requirement in `security.mdx`.
2. Identify the verifier-checklist step it exercises (or the pre-check).
3. Use only keypairs from `keys.json`, OR supply a documented `jwks_override` explaining why a non-canonical key shape is required.
4. Include `expected_signature_base` for positive vectors and for step-10 `request_signature_invalid` catchers.
5. Include `test_harness_state` for any vector that requires preloaded verifier state.
6. Carry exactly one fault (adcp#7577). A request MUST NOT contain a second fault that a verifier could detect through a different evaluation order, because multi-fault vectors implicitly grade verifier step ordering. Build the request so that every other check passes: cover `content-digest`, send a correct `Content-Digest`, and sign the base the verifier would otherwise verify. Keep a placeholder `Signature` only where no signature base can exist.
